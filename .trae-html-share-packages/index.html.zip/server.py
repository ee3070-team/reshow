import argparse
import hashlib
import json
import re
import ssl
import threading
import time
from email import policy
from email.message import Message
from email.parser import BytesParser
from functools import partial
from http.server import SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import unquote, urlsplit
from urllib.error import HTTPError
from urllib.request import HTTPRedirectHandler, Request, build_opener


ROOT = Path(__file__).resolve().parent
MAX_IMAGE_SIZE = 4 * 1024 * 1024
MAX_REQUEST_SIZE = MAX_IMAGE_SIZE + 32 * 1024
MAX_RESPONSE_SIZE = 256 * 1024
MAX_RFID_EVENT_SIZE = 4096
RFID_EVENT_FILE = ROOT / "hardware" / "rfid-events.jsonl"
RFID_EVENT_LOCK = threading.Lock()
RFID_WORKFLOW = {
    "phase": "idle",
    "uid": None,
    "exhibit_id": None,
}
RFID_LATEST_DEVICE_EVENT = None
PROMPT = """Analyze the attached image and identify the visible artifact. Return exactly one valid JSON object and no Markdown or extra text, using precisely these two keys:
{
  "name": "A short, specific title for the visible image",
  "description": "A concise description of details visible in the image."
}
Do not return a general image summary instead of this JSON. Do not infer facts that cannot be seen."""
THREEJS_GROUP_PROMPT = """Analyze the attached artifact image and build a recognizable low-poly Three.js model from its silhouette and visible details, not a generic blob. Return exactly one valid JSON object and no Markdown, with this schema:
{"parts":[{"shape":"sphere","position":[0,0,0],"scale":[1,1,1],"color":"#aabbcc"}]}
Include 8 to 12 parts. Each part must have exactly the keys shape, position, scale, and color. shape must be sphere, box, or cylinder. position must contain three numbers from -2.5 to 2.5. scale must contain three numbers greater than 0 and no greater than 3. color must be a six-digit hex color. Use boxes and cylinders for the main body, frame, rim, visor, handle, or base. Use at most three spheres, only for small rounded details or when the artifact itself is spherical; never replace a non-spherical artifact with one large sphere. Make parts different sizes and place them to form a clear silhouette instead of stacking them at the origin. Use a restrained palette of two to four colors based on the image. Keep the model upright with its main axis on Y. Do not include JavaScript, HTML, explanations, or facts not visible in the image."""
THREEJS_GROUP_STAGES = {
    "silhouette": {
        "previous": (0, 0),
        "new": (3, 4),
        "total": (3, 4),
        "instruction": "Build only the object's main silhouette from 3 to 4 large parts.",
    },
    "structure": {
        "previous": (3, 4),
        "new": (3, 4),
        "total": (6, 8),
        "instruction": "Add 3 to 4 major structural features that make this specific object recognizable.",
    },
    "details": {
        "previous": (6, 8),
        "new": (2, 4),
        "total": (8, 12),
        "instruction": "Add 2 to 4 small, visible details that refine this specific object.",
    },
}


class UploadError(ValueError):
    def __init__(self, status, message):
        super().__init__(message)
        self.status = status


def decode_json_response(response):
    try:
        value = json.loads(response.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError):
        return {}
    return value if isinstance(value, dict) else {}


class NoRedirects(HTTPRedirectHandler):
    def redirect_request(self, request, fp, code, message, headers, newurl):
        # A redirect must never receive a visitor's BYOK Authorization header.
        return None


def read_cloudflare_response(response):
    body = response.read(MAX_RESPONSE_SIZE + 1)
    if len(body) > MAX_RESPONSE_SIZE:
        raise RuntimeError("Cloudflare returned an oversized response.")
    return decode_json_response(body)


def cloudflare_request(endpoint, token, payload, timeout=40):
    request = Request(
        endpoint,
        data=json.dumps(payload).encode("utf-8"),
        headers={
            "Authorization": "Bearer " + token,
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with build_opener(NoRedirects()).open(request, timeout=timeout) as response:
            return response.status, read_cloudflare_response(response)
    except HTTPError as error:
        # Upstream bodies may echo credentials. Do not return or log them.
        return error.code, {}
    except OSError as error:
        raise RuntimeError("Cloudflare Workers AI could not complete the request. Try again.") from error


def extract_json_object(text):
    decoder = json.JSONDecoder()
    for index, character in enumerate(text):
        if character != "{":
            continue
        try:
            value, _ = decoder.raw_decode(text[index:])
        except json.JSONDecodeError:
            continue
        if isinstance(value, dict) and {
            "name",
            "description",
        }.issubset(value):
            name = value["name"]
            description = value["description"]
            if (
                not isinstance(name, str)
                or not isinstance(description, str)
                or not name.strip()
                or not description.strip()
            ):
                raise RuntimeError(
                    "The AI response contains invalid exhibit details. Please try again."
                )
            return name.strip(), description.strip()
    return None


def create_exhibit_name(description):
    first_sentence = re.split(r"(?<=[.!?])\s+", description, maxsplit=1)[0]
    first_sentence = re.sub(
        r"^the image\s+(presents|shows|depicts|features|contains)\s+",
        "",
        first_sentence,
        flags=re.IGNORECASE,
    )
    previous_end = 0
    for word in re.finditer(r"\S+", first_sentence):
        starts_clause = word.group().lower() in ("that", "which", "with")
        if word.group().lower() == "characterized":
            following = first_sentence[word.end():word.end() + 4]
            starts_clause = len(following) == 4 and following[:3].lower() == " by" and following[3].isspace()
        if starts_clause and word.start() > 0 and word.end() < len(first_sentence):
            first_sentence = first_sentence[:previous_end]
            break
        previous_end = word.end()
    name = first_sentence.strip(" \t\n\r.,:;\"'")
    name = re.sub(r"^(a|an|the)\s+", "", name, flags=re.IGNORECASE)
    return name[:1].upper() + name[1:] if name else "Image-based exhibit"


def vision_endpoint(account_id):
    return (
        "https://api.cloudflare.com/client/v4/accounts/"
        + account_id
        + "/ai/run/@cf/meta/llama-3.2-11b-vision-instruct"
    )


def describe_result(result):
    # Structural summary only; never echo upstream text or credentials.
    if isinstance(result, dict):
        notes = [
            "result object with keys: " + (", ".join(sorted(result)[:10]) or "(none)")
        ]
        response = result.get("response")
        if isinstance(response, str):
            notes.append("response is a string of length " + str(len(response)))
        elif isinstance(response, dict):
            notes.append(
                "response object with keys: " + (", ".join(sorted(response)[:10]) or "(none)")
            )
        else:
            notes.append("response type: " + type(response).__name__)
        usage = result.get("usage")
        if isinstance(usage, dict):
            completion = usage.get("completion_tokens")
            if isinstance(completion, int):
                notes.append("completion_tokens: " + str(completion))
        calls = result.get("tool_calls")
        if isinstance(calls, list):
            notes.append("tool_calls: " + str(len(calls)))
        return "; ".join(notes)
    if isinstance(result, list):
        return "result list of length " + str(len(result))
    if result is None:
        return "result is null"
    return "result type: " + type(result).__name__


GENERATED_TEXT_KEYS = (
    "response",
    "generated_text",
    "text",
    "content",
    "message",
    "answer",
    "output",
    "arguments",
    "choices",
)


def _find_text(value, key):
    if isinstance(value, dict):
        if key in value and isinstance(value[key], str) and value[key].strip():
            return value[key]
        for item in value.values():
            found = _find_text(item, key)
            if found:
                return found
    elif isinstance(value, list):
        for item in value:
            found = _find_text(item, key)
            if found:
                return found
    return None


def extract_generated_text(value):
    # Workers AI returns the generated answer as a plain string, nested inside a
    # chat-style object, or as an already-parsed JSON object. Prefer well-known
    # keys, then fall back to the raw JSON so callers can still locate the object
    # they expect (for example a {"parts": [...]} array).
    if isinstance(value, str):
        return value
    for key in GENERATED_TEXT_KEYS:
        found = _find_text(value, key)
        if found:
            return found
    if isinstance(value, (dict, list)):
        return json.dumps(value, separators=(",", ":"))
    return None


def generate_vision_text(
    image_bytes,
    account_id,
    api_token,
    prompt,
    max_tokens,
    timeout=40,
    retries=2,
):
    endpoint = vision_endpoint(account_id)
    last_error = None
    for attempt in range(retries + 1):
        try:
            status, response = cloudflare_request(
                endpoint,
                api_token,
                {
                    "prompt": prompt,
                    "image": list(image_bytes),
                    "max_tokens": max_tokens,
                    "temperature": 0.2,
                },
                timeout=timeout,
            )
            if not 200 <= status < 300:
                raise RuntimeError(
                    f"Cloudflare Workers AI rejected the request (HTTP {status}). "
                    "Check that your API token can run Workers AI on this account, "
                    "and that the model is enabled with any required terms accepted."
                )
            if not response.get("success"):
                raise RuntimeError(
                    "Cloudflare Workers AI rejected the request. Check your account, "
                    "token permissions, model access and accepted model terms."
                )

            result = response.get("result")
            generated = extract_generated_text(result)
            if (
                isinstance(generated, str)
                and generated.strip()
                and len(generated) <= 16000
            ):
                return generated.strip()
            last_error = RuntimeError(
                "Cloudflare returned no generated text (" + describe_result(result) + ")."
            )
        except RuntimeError as error:
            last_error = error
        if attempt < retries:
            time.sleep(1 + attempt)
    raise last_error or RuntimeError("Cloudflare Workers AI failed after retries.")


def generate_exhibit(image_bytes, account_id, api_token):
    generated = generate_vision_text(
        image_bytes, account_id, api_token, PROMPT, 512
    )
    details = extract_json_object(generated)
    if details is None:
        description = generated.strip()
        name = create_exhibit_name(description)
    else:
        name, description = details

    return {
        "exhibit_id": "demo-artifact-01",
        "name": name,
        "description": description,
        "tag_id": "DEMO-TAG-001",
        "temperature_min_c": 18,
        "temperature_max_c": 28,
        "brightness_min_raw": 600,
        "brightness_max_raw": 3000,
    }


def invalid_model(reason):
    return RuntimeError(
        "Workers AI returned an invalid 3D model (" + reason + "). Try again."
    )


def preview_text(text):
    collapsed = " ".join(str(text).split())
    return collapsed[:200] + ("..." if len(collapsed) > 200 else "")


def validate_model_parts(parts, minimum, maximum):
    if not isinstance(parts, list):
        raise invalid_model("parts is " + type(parts).__name__ + ", not a list")
    if not minimum <= len(parts) <= maximum:
        raise invalid_model(
            "got "
            + str(len(parts))
            + " parts, expected "
            + str(minimum)
            + " to "
            + str(maximum)
        )

    validated = []
    for index, part in enumerate(parts):
        label = "part " + str(index)
        if not isinstance(part, dict):
            raise invalid_model(label + " is " + type(part).__name__)
        if not {"shape", "position", "scale", "color"}.issubset(part):
            raise invalid_model(label + " keys: " + ", ".join(sorted(part)))
        if part["shape"] not in ("sphere", "box", "cylinder"):
            raise invalid_model(label + " shape: " + str(part["shape"])[:40])
        position = part["position"]
        scale = part["scale"]
        if not isinstance(position, list) or len(position) != 3:
            raise invalid_model(label + " position: " + json.dumps(position)[:60])
        if not isinstance(scale, list) or len(scale) != 3:
            raise invalid_model(label + " scale: " + json.dumps(scale)[:60])
        if any(
            not isinstance(component, (int, float))
            or isinstance(component, bool)
            or not -2.5 <= component <= 2.5
            for component in position
        ):
            raise invalid_model(
                label + " position out of range: " + json.dumps(position)[:60]
            )
        if any(
            not isinstance(component, (int, float))
            or isinstance(component, bool)
            or not 0 < component <= 3
            for component in scale
        ):
            raise invalid_model(
                label + " scale out of range: " + json.dumps(scale)[:60]
            )
        if not isinstance(part["color"], str) or not re.fullmatch(
            r"#[a-fA-F0-9]{6}", part["color"]
        ):
            raise invalid_model(label + " color: " + str(part["color"])[:40])
        validated.append(
            {
                "shape": part["shape"],
                "position": position,
                "scale": scale,
                "color": part["color"],
            }
        )
    if sum(part["shape"] == "sphere" for part in validated) > 3:
        raise RuntimeError("Workers AI returned a sphere-heavy 3D model. Try again.")
    return validated


def extract_model_parts(text, minimum=8, maximum=12):
    decoder = json.JSONDecoder()
    value = None
    for index, character in enumerate(text):
        if character != "{":
            continue
        try:
            candidate, _ = decoder.raw_decode(text[index:])
        except json.JSONDecodeError:
            continue
        if isinstance(candidate, dict):
            value = candidate
            if "parts" in candidate:
                break
    if not isinstance(value, dict):
        raise invalid_model("the response was: " + preview_text(text))
    if "parts" not in value:
        raise invalid_model(
            "the JSON object has keys: " + ", ".join(sorted(value)[:10])
        )
    return validate_model_parts(value.get("parts"), minimum, maximum)


FALLBACK_MODEL_PARTS = [
    {"shape": "box", "position": [0, 0, 0], "scale": [1.4, 0.2, 1.4], "color": "#8b4513"},
    {"shape": "box", "position": [0, 0.75, 0], "scale": [1.0, 1.2, 1.0], "color": "#d2b48c"},
    {"shape": "cylinder", "position": [0, 1.6, 0], "scale": [0.3, 0.3, 0.6], "color": "#8b4513"},
    {"shape": "box", "position": [-0.8, 0.75, 0], "scale": [0.15, 1.2, 1.0], "color": "#5d4037"},
    {"shape": "box", "position": [0.8, 0.75, 0], "scale": [0.15, 1.2, 1.0], "color": "#5d4037"},
    {"shape": "box", "position": [0, 1.9, 0], "scale": [1.3, 0.15, 1.3], "color": "#8b4513"},
    {"shape": "box", "position": [-0.6, 1.25, 0.5], "scale": [0.2, 0.5, 0.1], "color": "#5d4037"},
    {"shape": "box", "position": [0.6, 1.25, 0.5], "scale": [0.2, 0.5, 0.1], "color": "#5d4037"},
    {"shape": "box", "position": [-0.6, 1.25, -0.5], "scale": [0.2, 0.5, 0.1], "color": "#5d4037"},
    {"shape": "box", "position": [0.6, 1.25, -0.5], "scale": [0.2, 0.5, 0.1], "color": "#5d4037"},
    {"shape": "sphere", "position": [0, 2.0, 0], "scale": [0.15, 0.15, 0.15], "color": "#8b4513"},
    {"shape": "cylinder", "position": [0, 0.75, 0.7], "scale": [0.12, 0.12, 0.6], "color": "#d2b48c"},
]


def generate_model_group(image_bytes, account_id, api_token):
    try:
        generated = generate_vision_text(
            image_bytes, account_id, api_token, THREEJS_GROUP_PROMPT, 900, timeout=55
        )
        return {
            "stage": "silhouette",
            "parts": extract_model_parts(generated),
        }
    except Exception as error:
        return {
            "stage": "silhouette",
            "parts": FALLBACK_MODEL_PARTS,
            "fallback": True,
            "reason": str(error),
        }


def generate_model_group_step(
    image_bytes, account_id, api_token, stage, previous_parts
):
    settings = THREEJS_GROUP_STAGES[stage]
    minimum_previous, maximum_previous = settings["previous"]
    try:
        previous_parts = validate_model_parts(
            previous_parts, minimum_previous, maximum_previous
        )
    except Exception:
        previous_parts = list(FALLBACK_MODEL_PARTS[:maximum_previous])
    minimum_new, maximum_new = settings["new"]
    instruction = settings["instruction"]
    prompt = f"""Analyze the attached artifact image and incrementally build a recognizable low-poly Three.js model, not a generic blob.
This is the {stage} step. {instruction}
The existing model parts are: {json.dumps(previous_parts, separators=(",", ":"))}
Return exactly one valid JSON object and no Markdown, using this schema:
{{"parts":[{{"shape":"box","position":[0,0,0],"scale":[1,1,1],"color":"#aabbcc"}}]}}
Return only {minimum_new} to {maximum_new} NEW parts in the parts array; do not repeat the existing parts. Keep the object upright with its main axis on Y and align new parts to the existing coordinates. Each part must have exactly the keys shape, position, scale, and color. shape must be sphere, box, or cylinder. position must contain three numbers from -2.5 to 2.5. scale must contain three numbers greater than 0 and no greater than 3. color must be a six-digit hex color. Prefer boxes and cylinders for structural features. Use spheres only for small rounded details or when the artifact itself is spherical. Match the image's restrained two-to-four color palette. Do not include JavaScript, HTML, explanations, or facts not visible in the image."""
    try:
        generated = generate_vision_text(
            image_bytes, account_id, api_token, prompt, 650, timeout=55
        )
        new_parts = extract_model_parts(generated, minimum_new, maximum_new)
        combined = validate_model_parts(
            previous_parts + new_parts,
            settings["total"][0],
            settings["total"][1],
        )
        return {"stage": stage, "parts": combined, "fallback": False}
    except Exception as error:
        combined = list(previous_parts)
        if len(combined) < settings["total"][0]:
            combined = list(FALLBACK_MODEL_PARTS[: settings["total"][0]])
        return {
            "stage": stage,
            "parts": combined,
            "fallback": True,
            "reason": str(error),
        }


def multipart_message(content_type, body):
    if len(body) > MAX_REQUEST_SIZE:
        raise UploadError(413, "The image must be smaller than 4 MB.")
    if len(content_type) > 256 or "\r" in content_type or "\n" in content_type:
        raise UploadError(400, "The image upload could not be read.")
    if not content_type.lower().startswith("multipart/form-data;"):
        raise UploadError(400, "Choose a JPEG, PNG, or WebP image and try again.")
    header = Message()
    header["Content-Type"] = content_type
    boundary = header.get_boundary()
    if not boundary or not re.fullmatch(r"[A-Za-z0-9'()+_,./:=? -]{1,70}", boundary):
        raise UploadError(400, "The image upload boundary is invalid.")
    if body.count(b"--" + boundary.encode("ascii")) not in (4, 5, 6, 7):
        raise UploadError(400, "Upload exactly one image, account ID and API token.")
    try:
        message = BytesParser(policy=policy.default).parsebytes(
            ("Content-Type: " + content_type + "\r\nMIME-Version: 1.0\r\n\r\n").encode("ascii") + body
        )
    except (LookupError, UnicodeEncodeError) as error:
        raise UploadError(400, "The image upload could not be read.") from error
    if not message.is_multipart() or message.defects:
        raise UploadError(400, "The image upload could not be read.")
    return message


def uploaded_image(part):
    image = part.get_payload(decode=True) or b""
    if not image or len(image) > MAX_IMAGE_SIZE:
        raise UploadError(413, "The image must be smaller than 4 MB.")
    signatures = {
        "image/jpeg": image.startswith(b"\xff\xd8\xff"),
        "image/png": image.startswith(b"\x89PNG\r\n\x1a\n"),
        "image/webp": image.startswith(b"RIFF") and image[8:12] == b"WEBP",
    }
    if not signatures.get(part.get_content_type()):
        raise UploadError(415, "Only JPEG, PNG, and WebP images are supported.")
    return image


def uploaded_credential(part):
    value = part.get_payload(decode=True) or b""
    if len(value) > 4096:
        raise UploadError(400, "A request field is too long.")
    try:
        return value.decode("utf-8").strip()
    except UnicodeDecodeError as error:
        raise UploadError(400, "Request fields must be text.") from error


def parse_multipart_request(content_type, body):
    fields = {}
    image = None
    seen = set()
    for part in multipart_message(content_type, body).iter_parts():
        name = part.get_param("name", header="content-disposition")
        if part.get_content_disposition() != "form-data" or name not in (
            "image",
            "account_id",
            "api_token",
            "task",
            "stage",
            "previous_parts",
        ) or name in seen:
            raise UploadError(400, "Upload exactly one image, account ID and API token.")
        seen.add(name)
        if name == "image":
            image = uploaded_image(part)
        else:
            fields[name] = uploaded_credential(part)
    account_id = fields.get("account_id", "")
    api_token = fields.get("api_token", "")
    task = fields.get("task", "exhibit")
    if not re.fullmatch(r"[a-fA-F0-9]{32}", account_id):
        raise UploadError(400, "Enter a valid 32-character Cloudflare Account ID.")
    if not re.fullmatch(r"[A-Za-z0-9_-]{20,4096}", api_token):
        raise UploadError(400, "Enter a valid Cloudflare API token.")
    if image is None:
        raise UploadError(400, "Choose a JPEG, PNG, or WebP image and try again.")
    if task not in ("exhibit", "threejs_group"):
        raise UploadError(400, "Choose a supported Workers AI generation task.")
    stage = fields.get("stage")
    previous_parts_value = fields.get("previous_parts")
    if task == "exhibit" and (
        stage is not None or previous_parts_value is not None
    ):
        raise UploadError(400, "Choose a supported Workers AI generation task.")
    if stage is None:
        if previous_parts_value is not None:
            raise UploadError(400, "The 3D model step is invalid.")
        previous_parts = None
    else:
        settings = THREEJS_GROUP_STAGES.get(stage)
        if task != "threejs_group" or settings is None:
            raise UploadError(400, "The 3D model step is invalid.")
        try:
            previous_parts_data = json.loads(previous_parts_value or "[]")
        except json.JSONDecodeError as error:
            raise UploadError(400, "The 3D model step is invalid.") from error
        try:
            previous_parts = validate_model_parts(
                previous_parts_data, *settings["previous"]
            )
        except RuntimeError as error:
            raise UploadError(400, "The 3D model step is invalid.") from error
    return image, account_id, api_token, task, stage, previous_parts


class StudioHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=kwargs.pop("directory", str(ROOT)), **kwargs)

    def send_head(self):
        path = unquote(urlsplit(self.path).path)
        parts = Path(path.lstrip("/")).parts
        allowed = path in ("/", "/index.html", "/release.json") or (
            parts and parts[0] in ("css", "js", "assets")
            and not any(part.startswith(".") for part in parts)
        )
        target = Path(self.translate_path(self.path)).resolve()
        if path == "/":
            target = target / "index.html"
        if not allowed or not target.is_relative_to(Path(self.directory).resolve()) or not target.is_file():
            self.send_error(404)
            return None
        return super().send_head()

    def send_json(self, status, data):
        body = json.dumps(data).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = urlsplit(self.path).path
        if path == "/api/rfid/status":
            with RFID_EVENT_LOCK:
                status = dict(RFID_WORKFLOW)
            self.send_json(200, {"data": status})
            return
        if path == "/api/rfid/device-event":
            with RFID_EVENT_LOCK:
                event = dict(RFID_LATEST_DEVICE_EVENT) if RFID_LATEST_DEVICE_EVENT else None
            if event is None:
                self.send_json(404, {"error": "No RFID device event has been received yet."})
                return
            self.send_json(200, event)
            return
        super().do_GET()

    def do_POST(self):
        global RFID_LATEST_DEVICE_EVENT
        path = urlsplit(self.path).path
        if path == "/api/rfid/device-event":
            try:
                content_length = int(self.headers.get("Content-Length", "0"))
            except ValueError:
                self.send_json(400, {"error": "Invalid request length."})
                return
            if content_length <= 0 or content_length > MAX_RFID_EVENT_SIZE:
                self.send_json(400, {"error": "Invalid RFID device event."})
                return
            try:
                event = json.loads(self.rfile.read(content_length).decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                self.send_json(400, {"error": "Invalid RFID device event JSON."})
                return
            if not isinstance(event, dict) or set(event) not in (
                {"type", "uid", "result"},
                {"type", "uid", "result", "exhibit_id"},
            ):
                self.send_json(400, {"error": "RFID event must contain type, uid, result, and optional exhibit_id."})
                return
            uid = event.get("uid")
            result = event.get("result")
            exhibit_id = event.get("exhibit_id")
            if event.get("type") != "rfid_event":
                self.send_json(400, {"error": "RFID event type must be rfid_event."})
                return
            if not isinstance(uid, str) or not re.fullmatch(r"[A-Fa-f0-9]{4,20}", uid):
                self.send_json(400, {"error": "Invalid RFID UID."})
                return
            if result not in ("accepted", "denied"):
                self.send_json(400, {"error": "RFID result must be accepted or denied."})
                return
            if result == "accepted" and (
                not isinstance(exhibit_id, str)
                or not exhibit_id.strip()
                or len(exhibit_id) > 100
            ):
                self.send_json(400, {"error": "Accepted RFID events require a valid exhibit_id."})
                return
            if exhibit_id is not None and (
                not isinstance(exhibit_id, str) or not exhibit_id.strip() or len(exhibit_id) > 100
            ):
                self.send_json(400, {"error": "Invalid exhibit_id."})
                return
            normalized_event = {
                "type": "rfid_event",
                "uid": uid.upper(),
                "result": result,
            }
            if exhibit_id is not None:
                normalized_event["exhibit_id"] = exhibit_id.strip()
            with RFID_EVENT_LOCK:
                RFID_LATEST_DEVICE_EVENT = normalized_event
            self.send_json(200, normalized_event)
            return

        if path == "/api/rfid/access-event":
            try:
                content_length = int(self.headers.get("Content-Length", "0"))
            except ValueError:
                self.send_json(400, {"error": "Invalid request length."})
                return
            if content_length <= 0 or content_length > MAX_RFID_EVENT_SIZE:
                self.send_json(400, {"error": "Invalid RFID event."})
                return
            try:
                event = json.loads(self.rfile.read(content_length).decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                self.send_json(400, {"error": "Invalid RFID event JSON."})
                return
            uid = event.get("uid") if isinstance(event, dict) else None
            result = event.get("result") if isinstance(event, dict) else None
            door = event.get("door") if isinstance(event, dict) else None
            phase = event.get("phase") if isinstance(event, dict) else None
            exhibit_id = event.get("exhibit_id") if isinstance(event, dict) else None
            if not isinstance(uid, str) or not re.fullmatch(r"[A-Fa-f0-9]{4,20}", uid):
                self.send_json(400, {"error": "Invalid RFID UID."})
                return
            if result not in ("accepted", "denied") or door not in ("opened", "closed"):
                self.send_json(400, {"error": "Invalid RFID event result."})
                return
            if phase not in ("first_scan_pending", "second_scan_confirmed", "pending_edit_waiting", "denied"):
                self.send_json(400, {"error": "Invalid RFID workflow phase."})
                return
            with RFID_EVENT_LOCK:
                if phase == "first_scan_pending":
                    if RFID_WORKFLOW["phase"] != "idle":
                        self.send_json(409, {"error": "An exhibit edit is already pending."})
                        return
                    if not isinstance(exhibit_id, str) or not exhibit_id.strip():
                        self.send_json(400, {"error": "ESP32 must provide the exhibit ID for the first scan."})
                        return
                    RFID_WORKFLOW.update({
                        "phase": "pending_edit",
                        "uid": uid.upper(),
                        "exhibit_id": exhibit_id.strip(),
                    })
                elif phase == "second_scan_confirmed":
                    if (
                        RFID_WORKFLOW["phase"] != "ready_to_confirm"
                        or RFID_WORKFLOW["uid"] != uid.upper()
                    ):
                        self.send_json(409, {"error": "The second scan is not confirmed by staff."})
                        return
                    RFID_WORKFLOW.update({
                        "phase": "idle",
                        "uid": uid.upper(),
                    })
                    RFID_WORKFLOW["exhibit_id"] = None
                record = {
                    "uid": uid.upper(),
                    "result": result,
                    "door": door,
                    "phase": phase,
                    "exhibit_id": exhibit_id.strip() if isinstance(exhibit_id, str) else RFID_WORKFLOW["exhibit_id"],
                }
                with RFID_EVENT_FILE.open("a", encoding="utf-8") as event_file:
                    event_file.write(json.dumps(record, separators=(",", ":")) + "\n")
            with RFID_EVENT_LOCK:
                workflow = dict(RFID_WORKFLOW)
            self.send_json(200, {"data": {"recorded": True, **workflow}})
            return

        if path == "/api/rfid/staff-ready":
            try:
                content_length = int(self.headers.get("Content-Length", "0"))
                json.loads(self.rfile.read(content_length).decode("utf-8"))
            except (ValueError, UnicodeDecodeError, json.JSONDecodeError):
                self.send_json(400, {"error": "Invalid staff confirmation message."})
                return
            with RFID_EVENT_LOCK:
                if RFID_WORKFLOW["phase"] != "pending_edit":
                    self.send_json(409, {"error": "No RFID exhibit edit is pending."})
                    return
                if not isinstance(RFID_WORKFLOW["exhibit_id"], str) or not RFID_WORKFLOW["exhibit_id"]:
                    self.send_json(409, {"error": "The ESP32 has not assigned an exhibit ID."})
                    return
                RFID_WORKFLOW.update({
                    "phase": "ready_to_confirm",
                })
                workflow = dict(RFID_WORKFLOW)
            self.send_json(200, {"data": workflow})
            return

        if path == "/api/technology/agree-terms":
            try:
                content_length = int(self.headers.get("Content-Length", "0"))
            except ValueError:
                self.send_json(400, {"error": "Invalid request length."})
                return
            if content_length <= 0 or content_length > 8192:
                self.send_json(400, {"error": "Enter the Cloudflare Account ID and API token first."})
                return
            try:
                payload = json.loads(self.rfile.read(content_length).decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                self.send_json(400, {"error": "Enter the Cloudflare Account ID and API token first."})
                return
            account_id = payload.get("account_id") if isinstance(payload, dict) else None
            api_token = payload.get("api_token") if isinstance(payload, dict) else None
            if not isinstance(account_id, str) or not re.fullmatch(r"[a-fA-F0-9]{32}", account_id):
                self.send_json(400, {"error": "Enter a valid 32-character Cloudflare Account ID."})
                return
            if not isinstance(api_token, str) or not re.fullmatch(r"[A-Za-z0-9_-]{20,4096}", api_token):
                self.send_json(400, {"error": "Enter a valid Cloudflare API token."})
                return
            try:
                status, response = cloudflare_request(
                    vision_endpoint(account_id),
                    api_token,
                    {"prompt": "agree"},
                    timeout=30,
                )
                if not 200 <= status < 300 or not response.get("success"):
                    raise RuntimeError(
                        f"Cloudflare Workers AI rejected the model terms (HTTP {status}). "
                        "Check your account, token permissions and model access."
                    )
            except RuntimeError as error:
                self.send_json(502, {"error": str(error)})
                return
            self.send_json(200, {"data": {"agreed": True}})
            return

        if path != "/api/technology/generate-exhibit":
            self.send_json(404, {"error": "Not found."})
            return

        try:
            content_length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            self.send_json(400, {"error": "Invalid request length."})
            return
        if content_length <= 0:
            self.send_json(400, {"error": "Choose an image and try again."})
            return
        if content_length > MAX_REQUEST_SIZE:
            self.send_json(413, {"error": "The image must be smaller than 4 MB."})
            return

        try:
            image, account_id, api_token, task, stage, previous_parts = parse_multipart_request(
                self.headers.get("Content-Type", ""),
                self.rfile.read(content_length),
            )
            if task == "threejs_group":
                generated = (
                    generate_model_group_step(
                        image,
                        account_id,
                        api_token,
                        stage,
                        previous_parts,
                    )
                    if stage is not None
                    else generate_model_group(image, account_id, api_token)
                )
            else:
                generated = generate_exhibit(image, account_id, api_token)
            self.send_json(
                200, {"data": generated}
            )
        except UploadError as error:
            self.send_json(error.status, {"error": str(error)})
        except RuntimeError as error:
            self.send_json(502, {"error": str(error)})


def main():
    parser = argparse.ArgumentParser(
        description="Serve the ReShow dashboard and its 3D/AI studio API."
    )
    parser.add_argument("--bind", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--directory", default=str(ROOT))
    parser.add_argument("--cert-file", help="PEM certificate chain for local HTTPS")
    parser.add_argument("--key-file", help="PEM private key for the certificate")
    args = parser.parse_args()
    if bool(args.cert_file) != bool(args.key_file):
        raise SystemExit("Both --cert-file and --key-file are required for HTTPS.")

    if args.cert_file:
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.minimum_version = ssl.TLSVersion.TLSv1_2
        context.load_cert_chain(certfile=args.cert_file, keyfile=args.key_file)
        try:
            from http.server import ThreadingHTTPSServer
        except ImportError as error:
            raise SystemExit("Local HTTPS hosting requires Python 3.14 or later; the Lambda API supports Python 3.12.") from error
        server = ThreadingHTTPSServer(
            (args.bind, args.port), partial(StudioHandler, directory=args.directory),
            certfile=args.cert_file, keyfile=args.key_file,
        )
        protocol = "HTTPS"
    else:
        from http.server import ThreadingHTTPServer
        server = ThreadingHTTPServer(
            (args.bind, args.port), partial(StudioHandler, directory=args.directory)
        )
        protocol = "HTTP"
    try:
        print(
            "ReShow " + protocol + " is listening on " + args.bind + ":" + str(server.server_port),
            flush=True,
        )
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping ReShow server.", flush=True)
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
